from data_loader.loader import data_loader
from models.VggNet import SimpleVGGNet
from utils import painting,submit
# 数据加载、处理
print("数据加载，数据处理")
x_train,y_train,x_test,labels =  data_loader()
# 导入模型
model = SimpleVGGNet.build(64,64,3,3)
# 调参compile里包括loss,optimizer,metrics
model.compile(loss="categorical_crossentropy",optimizer="adam",metrics=["accuracy"])
# 开始训练并记录
history = model.fit(x_train,y_train,batch_size=32,epochs=30,verbose=1,validation_split=0.1)
# 画图
painting.painting(history=history,model=model)
# 输出
submit.submit(model=model,test=x_test,labels=labels)


