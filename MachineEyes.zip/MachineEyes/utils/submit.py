#输出预测结果
import numpy as np
import pandas as pd
import pickle
import cv2

def submit(model,test,labels):
    results = model.predict(test)
    results = results.argmax(axis=1)
    label = pd.Series(results,name='label')
    submission = pd.concat([pd.Series(range(1,len(test)),name='ImageId'),label],axis=1)
    submission.to_csv('submit0.csv',index=False)
 # 在图像画出来
def lookatpicture(model,image,lb):
    preds = model.predict(image)
    # 得到预测结果以及其对应的标签
    i = preds.argmax(axis=1)[0]
    label = [i]
    # 在图像中把结果画出来
    text = "{}: {:.2f}%".format(label, preds[0][i] * 100)
    cv2.putText(image2, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
    # 绘图
    cv2.imshow("Image", image2)
    cv2.waitKey(1)

