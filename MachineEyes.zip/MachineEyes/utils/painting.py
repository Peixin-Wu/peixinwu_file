from tensorflow.keras.utils import plot_model
import matplotlib.pyplot as plt
def painting(history,model):
    loss = []
    acc = []
    val_loss = []
    val_acc = []
    #画图
    loss.extend(history.history['loss'])
    acc.extend(history.history['accuracy'])
    val_loss.extend(history.history['val_loss'])
    val_acc.extend(history.history['val_accuracy'])
    model.summary()
    plot_model(model,to_file='MODEL.png',show_shapes=True)
    x = range(1, len(acc) + 1)
    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    plt.plot(x, acc, 'b', label='Training acc')
    plt.plot(x, val_acc, 'r', label='Validation acc')
    plt.title('Training and validation accuracy')
    plt.legend()
    plt.subplot(1, 2, 2)
    plt.plot(x, loss, 'b', label='Training loss')
    plt.plot(x, val_loss, 'r', label='Validation loss')
    plt.title('Training and validation loss')
    plt.legend()
    plt.savefig('loss-acc.png')
