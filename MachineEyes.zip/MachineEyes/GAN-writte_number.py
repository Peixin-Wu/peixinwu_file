from data_loader.GAN_MNIST_loader import loader
from models.GAN.generator import generator
from models.GAN.discriminator import discriminator
from tensorflow.keras.optimizers import Adam
from utils.save_imshow import save_pred_img
from keras.models import Model
from keras.layers import Input

import numpy as np
# 加载数据
x_train,y_train,x_test,y_test,noise,batch_size = loader()
imgshape =(28,28,1)
dim = 100
optimizer = Adam(0.0002)

# 配置鉴别器
D_model = discriminator(img_shape=imgshape)
D_model.compile(loss='binary_crossentropy',optimizer=optimizer,metrics=['accuracy'])

# 配置生成器
G_model = generator(imgshape,dim)
inputs = Input(shape=(dim,))
a = G_model(inputs)
D_model.trainable = False
yanzhen = D_model(a)
combine = Model(inputs,yanzhen)
combine.compile(optimizer=optimizer,loss="binary_crossentropy")
count = 10000
seq = 500
zhen = np.ones((batch_size,1))
jia  = np.zeros((batch_size,1))
for i in range(count):
    idx = np.random.randint(0,x_train.shape[0],batch_size)
    x_batch = x_train[idx]
    # y_batch = y_train[idx]
    gen_img = G_model.predict(noise)
    loss_real = D_model.train_on_batch(x_batch,zhen)
    loss_fake = D_model.train_on_batch(gen_img,jia)
    loss_D = 0.5 * np.add(loss_fake,loss_real)
    loss_G = combine.train_on_batch(noise,zhen)
    print ("%d [D loss: %f, acc.: %.2f%%] [G loss: %f]" % (i, loss_D[0], 100*loss_D[1], loss_G))
    # 保存500
    if i % seq == 0:
        save_pred_img(gen_img,i)







