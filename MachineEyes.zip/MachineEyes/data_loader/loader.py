# 加载数据
import pathlib
import cv2
import numpy as np
from sklearn.preprocessing import LabelEncoder,LabelBinarizer
def data_loader():
    dataset = "./dataset/train"
    testset = "./dataset/test"
    data = pathlib.Path(dataset)
    all_img_path = sorted(list(data.glob("*/*")))
    test_data = pathlib.Path(testset)
    test_path = sorted(list(test_data.glob("*/*")))
    x_train = []
    x_test = []
    labels = []
    for i in all_img_path:
        img_path = str(i)
        image = cv2.imread(img_path)
        image = cv2.resize(image,(64,64))
        x_train.append(image)#加载图片
        label = img_path.split("\\")[-2] #整标签
        labels.append(label)
    for i in test_path:
        testpath = str(i)
        image = cv2.imread(testpath)
        image = cv2.resize(image,(64,64))
        x_test.append(image)#加载图片
    # 数据处理
    x_train = np.array(x_train, np.float32) / 255
    x_test = np.array(x_test, np.float32) / 255
    # 标签one-hot处理
    lb = LabelBinarizer()
    y_train = lb.fit_transform(np.array(labels))
    labels = lb.classes_
    return x_train,y_train ,x_test,labels



