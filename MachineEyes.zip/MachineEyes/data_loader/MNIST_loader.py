def MNISTload():
    import pandas as pd
    import numpy as np
    from keras.utils.np_utils import to_categorical
    #读取CSV数据
    train = pd.read_csv("./dataset/MNINST_dataset/train.csv")
    test = pd.read_csv("./dataset/MNINST_dataset/test.csv")
    # x去掉第一列标签数据,y留第一列
    x_train = train.drop(labels="label",axis=1)
    y_train = train["label"]
    # x归一化，
    x_train = (x_train/255).values.reshape(-1,28,28,1)
    test = (test/255).values.reshape(-1,28,28,1)
    # karas版ont-hot
    y_train = to_categorical(y_train,num_classes=10)
    labels = [0,1,2,3,4,5,6,7,8,9]
    print(labels)
    return x_train,y_train,test,labels
