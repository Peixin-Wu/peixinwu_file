
import numpy as np
from keras.datasets import mnist
from keras.utils.np_utils import to_categorical
def loader():
    (x_train, y_train), (x_test, y_test) = mnist.load_data()
    x_train = x_train/127.5 - 1
    x_test = x_test/127.5 - 1
    x_train = np.expand_dims(x_train,axis=3)
    x_test = np.expand_dims(x_test,axis=3)
    y_train = to_categorical(y_train,num_classes=10)
    y_test = to_categorical(y_test,num_classes=10)
    batch_size = 25
    noise = np.random.normal(0,1,(batch_size,100))
    return x_train,y_train,x_test,y_test,noise,batch_size
