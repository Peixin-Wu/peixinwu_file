from data_loader.MNIST_loader import MNISTload
x_train,y_train,test,labels = MNISTload()
from models.VggNet import SimpleVGGNet
model = SimpleVGGNet.build(28,28,1,10)
model.compile(loss="categorical_crossentropy",optimizer="adam",metrics=["accuracy"])
history = model.fit(x_train,y_train,batch_size=64,epochs=1,verbose=1,validation_split=0.1,shuffle=True)
# 画图
from utils import painting,submit
painting.painting(history=history,model=model)
# 输出
submit.submit(model=model,test=test,labels=labels)
# 保存模型
model.save('./save_models/model')
